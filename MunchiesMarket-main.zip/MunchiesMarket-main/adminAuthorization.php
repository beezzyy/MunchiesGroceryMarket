<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="p7-p12/CSS/adminAuth.css">
    <title>Access Denied</title>
</head>

<body>
    <div id="overview">
        <div>
            <a href="index.php">


                <img src="Munchies.jpg" alt="Logo">
            </a>
            <h2>MUNCHIES MARKET</h2>

        </div>
    </div>

    <div class="container">
        <h1>Access Denied</h1>
        <p>You are not authorized in this section. <a href="Aisle/login.php">Login</a> or <a href="index.php">Home Page</a></p>
    </div>
</body>

</html>