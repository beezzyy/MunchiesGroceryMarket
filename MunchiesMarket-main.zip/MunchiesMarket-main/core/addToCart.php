<?php

session_start();

echo 'dis dikk';

?>