<?php
	session_start();
	$id = $_GET['id'];

	$users = simplexml_load_file('../../Database/user.xml');

	//we're are going to create iterator to assign to each product
	$index = 0;
	$i = 0;

	foreach($users->user as $user){
		if($user->id == $id){
			$index = $i;
			break;
		}
		$i++;
	}

	unset($users->user[$index]);
	file_put_contents('../../Database/user.xml', $users->asXML());

	$_SESSION['message'] = 'Product deleted successfully';
	header('location: Users.php');

?>