<?php
function check_login($con){

    if(isset($_SESSION['user_id']));
};