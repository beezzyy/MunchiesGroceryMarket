<?php


setcookie("user","ADMIN",time()+3600);

